"""Probes for the Notebook Review Framework v1 review of tutorials/blip_vqa_colab.ipynb (blip-vqa-pipeline).

Usage:  python run_probes.py <notebook.ipynb> <repo_clone_with_staged_weights> <workdir> <results.json> <which>
  which = static | byod | default   (default = P1 default path + P2 documented-experiment rerun)

Environment: CPU only (CUDA_VISIBLE_DEVICES=-1), HF_HUB_OFFLINE=1, DIMER_NOTEBOOK_CI_PREINSTALLED=1 (install
cell skipped; the interpreter already holds the notebook's exact pins with CPU torch). Code cells run VERBATIM
from the notebook JSON in one namespace; only form-field literals are substituted, and
google.colab.files.upload is replaced by a fake for BYOD. Real weights and the pinned VizWiz photographs are
hard-linked (read-only use) from the local clone; the manifest is written by the notebook itself; annotations
are copied. Nothing is downloaded. Results are appended to results.json after every step (write-immediately).
"""
from __future__ import annotations

import io
import json
import os
import re
import shutil
import sys
import time
import types
import zipfile
from pathlib import Path

os.environ.setdefault('CUDA_VISIBLE_DEVICES', '-1')
os.environ.setdefault('HF_HUB_OFFLINE', '1')
os.environ['DIMER_NOTEBOOK_CI_PREINSTALLED'] = '1'
os.environ.setdefault('KMP_DUPLICATE_LIB_OK', 'TRUE')

NB, CLONE, WORK, OUT, WHICH = (Path(sys.argv[1]), Path(sys.argv[2]), Path(sys.argv[3]), Path(sys.argv[4]), sys.argv[5])
nb = json.loads(NB.read_text(encoding='utf-8'))
cells = nb['cells']
code = {i: ''.join(c['source']) for i, c in enumerate(cells) if c['cell_type'] == 'code'}

results = json.loads(OUT.read_text(encoding='utf-8')) if OUT.exists() else {}


def save(key, value):
    results[key] = value
    OUT.write_text(json.dumps(results, indent=1, default=str), encoding='utf-8')


def with_params(src, **params):
    for name, value in params.items():
        src, n = re.subn(rf'^{name} = .*?(  # @param.*)$', lambda m: f'{name} = {value!r}{m.group(1)}', src, flags=re.M)
        assert n == 1, name
    return src


def run(ns, idx, **params):
    t0 = time.perf_counter()
    exec(compile(with_params(code[idx], **params), f'<cell {idx}>', 'exec'), ns)
    return round(time.perf_counter() - t0, 1)


# ---------------------------------------------------------------- P0 static
if WHICH == 'static':
    md = [''.join(c['source']) for c in cells if c['cell_type'] == 'markdown']
    alltext = '\n'.join(md)
    compiled = {}
    for i, s in code.items():
        try:
            compile(s, f'<cell {i}>', 'exec')
            compiled[i] = 'ok'
        except SyntaxError as e:
            compiled[i] = repr(e)
    markers = {k: len(re.findall(p, alltext, flags=re.I)) for k, p in {
        'intended_learner': r'intended (learner|audience)|who this is for',
        'how_to_use': r'how to use this notebook',
        'roadmap': r'roadmap',
        'glossary': r'glossary',
        'predict': r'\bpredict(ion)?\b',
        'checkpoint': r'checkpoint|check your (reasoning|understanding)',
        'troubleshooting': r'troubleshoot',
        'conclusion_template': r'conclusion template|write your conclusion',
        'look_for': r'look for',
        'watch': r'\bwatch\b',
        'rerun_instruction': r're-?run (from|cells?|section)',
    }.items()}
    carried = [(i, ''.join(c['source']).count('\n') + 1) for i, c in enumerate(cells)
               if c['metadata'].get('dimer', {}).get('embedded_module')]
    save('P0_static', {
        'cells': len(cells), 'code_cells': len(code), 'compile': compiled,
        'doubled_braces_in_markdown': {i: re.findall(r'\{\{[^}]*\}\}', ''.join(c['source']))
                                       for i, c in enumerate(cells) if c['cell_type'] == 'markdown'
                                       and '{{' in ''.join(c['source'])},
        'guided_markers': markers,
        'cellView_form': sum(1 for c in cells if c['metadata'].get('cellView') == 'form'),
        'carried_module_cells_lines': carried, 'carried_total_lines': sum(n for _, n in carried),
        'top_level_result_asserts': [(i, l) for i, s in code.items() for l in s.splitlines() if l.startswith('assert ')],
        'declared_spec': nb['metadata']['dimer'].get('notebook_spec'),
    })
    sys.exit(0)

# ---------------------------------------------------------------- workdir
WORK.mkdir(parents=True, exist_ok=True)
os.chdir(WORK)
wb = WORK / 'weights' / 'blip-vqa-base'
wb.mkdir(parents=True, exist_ok=True)
src_w = CLONE / 'weights' / 'blip-vqa-base'
for f in src_w.iterdir():
    if f.name == 'dimer-base-manifest.json' or (wb / f.name).exists():
        continue  # the notebook writes its own manifest; never write through a hard link
    os.link(f, wb / f.name)
vz = WORK / 'weights' / 'vizwiz' / 'images'
vz.mkdir(parents=True, exist_ok=True)
if not (WORK / 'weights' / 'vizwiz' / 'annotations.json').exists():
    shutil.copy2(CLONE / 'weights' / 'vizwiz' / 'annotations.json', WORK / 'weights' / 'vizwiz' / 'annotations.json')
for f in (CLONE / 'weights' / 'vizwiz' / 'images').iterdir():
    if not (vz / f.name).exists():
        os.link(f, vz / f.name)

ns: dict = {'__name__': '__main__'}
# carried modules + install (skipped) cell
for i in (3, 5, 7, 9):
    run(ns, i)

# ---------------------------------------------------------------- P3 BYOD Section 4 (no model)
if WHICH == 'byod':
    from PIL import Image, ImageDraw

    def stand_in(k):
        img = Image.new('RGB', (96, 96), ((k * 37) % 256, (k * 91) % 256, (k * 53) % 256))
        ImageDraw.Draw(img).ellipse([20, 20, 76, 76], fill=(255 - (k * 37) % 256, 200, 40))
        b = io.BytesIO(); img.save(b, format='PNG'); return b.getvalue()

    def make_zip(n, *, prefix='', name='records.jsonl', fmt='jsonl', tag='a', with_records=True):
        buf = io.BytesIO()
        with zipfile.ZipFile(buf, 'w') as z:
            recs = []
            for k in range(n):
                z.writestr(f'{prefix}img_{tag}_{k:03d}.png', stand_in(k))
                recs.append({'id': f'{tag}{k}', 'image': f'{prefix}img_{tag}_{k:03d}.png', 'question': 'what color is the circle?', 'answers': ['yellow']})
            if with_records:
                z.writestr(name, '\n'.join(json.dumps(r) for r in recs) if fmt == 'jsonl' else json.dumps(recs))
        return buf.getvalue()

    def section4(upload):
        colab = types.ModuleType('google.colab'); files = types.SimpleNamespace(upload=lambda: upload)
        colab.files = files; sys.modules['google'] = types.ModuleType('google'); sys.modules['google.colab'] = colab
        sys.modules['google'].colab = colab
        try:
            t = run(ns, 13, USE_BYOD=True)
            return {'ok': True, 'seconds': t, 'data_source': ns['data_source'], 'splits': ns['disjoint'],
                    'ids_prefixes': sorted({r['id'][0] for r in ns['train_records']})}
        except BaseException as e:  # noqa: BLE001
            return {'ok': False, 'error': f'{type(e).__name__}: {str(e)[:200]}'}

    out = {}
    for n in (8, 12, 20, 40, 49, 50, 60):
        shutil.rmtree('work/byod', ignore_errors=True)
        out[f'n={n}'] = section4({f'n{n}.zip': make_zip(n)})
    # API scan of the smallest dataset that passes split_dataset + per-split validate_dataset
    smallest = None
    shutil.rmtree('work/byod', ignore_errors=True)
    os.makedirs('work/scan', exist_ok=True)
    for k in range(80):
        p = Path('work/scan') / f's{k}.png'
        if not p.exists():
            p.write_bytes(stand_in(k))
    for n in range(8, 81):
        recs = [{'id': f's{k}', 'image': f's{k}.png', 'question': 'q?', 'answers': ['a']} for k in range(n)]
        try:
            sp = ns['split_dataset'](recs, seed=42, base_dir='work/scan')
            for part in sp.values():
                ns['validate_dataset'](part)
            smallest = n
            break
        except ValueError:
            continue
    out['smallest_passing_api_scan'] = smallest
    save('P3_byod_partial', out)
    # stale second upload: A uses records.jsonl, B uses records.json
    shutil.rmtree('work/byod', ignore_errors=True)
    a = section4({'a.zip': make_zip(60, tag='a')})
    b = section4({'b.zip': make_zip(60, tag='b', name='records.json', fmt='json')})
    out['stale_second_upload'] = {'first': a, 'second': b}
    shutil.rmtree('work/byod', ignore_errors=True)
    out['subfolder_refs'] = section4({'sub.zip': make_zip(60, prefix='photos/', tag='c')})
    shutil.rmtree('work/byod', ignore_errors=True)
    out['cancelled_upload'] = section4({})
    shutil.rmtree('work/byod', ignore_errors=True)
    out['zip_without_records'] = section4({'norec.zip': make_zip(60, tag='d', with_records=False)})
    # provenance print under BYOD: does cell 13 still print the VizWiz column digest / pinned photographs?
    shutil.rmtree('work/byod', ignore_errors=True)
    buf = io.StringIO(); old = sys.stdout; sys.stdout = buf
    try:
        section4({'p.zip': make_zip(60, tag='p')})
    finally:
        sys.stdout = old
    first = buf.getvalue().splitlines()[0] if buf.getvalue() else ''
    out['byod_first_print'] = first[:400]
    # majority-answer structure of the default VizWiz test split (no model needed)
    shutil.rmtree('work/byod', ignore_errors=True)
    run(ns, 13)
    from collections import Counter, defaultdict
    maj = ns['majority_answer']
    per = defaultdict(Counter)
    for r in ns['test_records']:
        m = maj(r['answers'])
        per[r['category']]['n'] += 1
        per[r['category']]['majority_unanswerable'] += int(m == 'unanswerable')
        per[r['category']]['unanswerable_among_answers'] += int(any(ns['normalize_answer'](a) == 'unanswerable' for a in r['answers']))
        per[r['category']]['constant_vqa_acc_sum_x100'] += round(100 * ns['vqa_accuracy']('unanswerable', ns['gold_texts'](r)))
    out['test_split_majority_structure'] = {k: dict(v) for k, v in per.items()}
    out['constant_baseline_test'] = {k: round(v, 3) for k, v in ns['constant_answer_baseline'](ns['test_records']).items() if isinstance(v, float)}
    save('P3_byod', out)
    results.pop('P3_byod_partial', None); save('P3_byod', out)
    sys.exit(0)

# ---------------------------------------------------------------- P4 fresh base, non-improving run -> Section 8 assert
if WHICH == 'assert':
    t = {}
    for i in (11, 13, 15, 17):
        t[i] = run(ns, i)
    t[19] = run(ns, 19, EPOCHS=1, LEARNING_RATE=1e-7)
    out = {'change': 'fresh kernel, EPOCHS = 1, LEARNING_RATE = 1e-7 (in the allowed range (0, 1e-3]); cells 11-19 then 21, 23',
           'history_val_vqa': [h['val']['vqa_accuracy'] for h in ns['adapt_result']['history']],
           'best_epoch': ns['adapt_result']['best_epoch'], 'seconds': t}
    for i in (21, 23):
        try:
            t[i] = run(ns, i)
            out[f'cell_{i}'] = 'ok'
        except BaseException as e:  # noqa: BLE001
            out[f'cell_{i}'] = f'{type(e).__name__}: {str(e)[:200]}'
            break
    out['adapted_vs_frozen_test_vqa'] = [round(ns['adapted_test']['vqa_accuracy'], 4) if 'adapted_test' in ns else None, round(ns['frozen_test']['vqa_accuracy'], 4)]
    out['evaluation_report_written'] = os.path.exists('outputs/blip_vqa_evaluation_report.json')
    out['result_json_written'] = os.path.exists('outputs/blip_vqa_result.json')
    out['adapter_written'] = os.path.exists('outputs/blip_vqa_adapter')
    save('P4_nonimproving_fresh_base', out)
    sys.exit(0)

# ---------------------------------------------------------------- P1 default path
assert WHICH == 'default'
log = []
_orig_answer = ns['BlipVQAPipeline'].answer


def logged_answer(self, image, question, **kw):
    r = _orig_answer(self, image, question, **kw)
    log.append({'adapted': self.adapter is not None, 'obj': id(self), 'question': r['question'], 'answer': r['answer']})
    return r


ns['BlipVQAPipeline'].answer = logged_answer
timing = {}
for i in (11, 13, 15, 17, 19, 21, 23):
    timing[i] = run(ns, i)
    save('P1_progress', {'completed_cells': list(timing), 'seconds': timing})
cmp = ns['comparison']
hist = ns['adapt_result']['history']
# analyse adapted answers on the test split by category
norm = ns['normalize_answer']
test_q = {ns['normalize_answer'](r['question']): r for r in ns['test_records']}
pipe_id = id(ns['pipe'])
# the adapted evaluate() on the test split is the first adapted pass over test questions after cell 19
adapted_calls = [e for e in log if e['adapted'] and e['obj'] == pipe_id]
first_test = {}
for e in adapted_calls:
    q = ns['normalize_answer'](e['question'])
    if q in test_q and q not in first_test:
        first_test[q] = e['answer']
frozen_calls = [e for e in log if not e['adapted']]
frozen_test_ans = {}
for e in frozen_calls:
    q = ns['normalize_answer'](e['question'])
    if q in test_q and q not in frozen_test_ans:
        frozen_test_ans[q] = e['answer']
from collections import defaultdict
cat = defaultdict(lambda: {'n': 0, 'adapted_says_unanswerable': 0, 'vqa_from_unanswerable': 0.0, 'vqa_from_content': 0.0,
                           'frozen_vqa': 0.0, 'frozen_says_unanswerable': 0})
for q, r in test_q.items():
    c = cat[r['category']]
    c['n'] += 1
    g = ns['gold_texts'](r)
    a = first_test.get(q, '')
    s = ns['vqa_accuracy'](a, g)
    if norm(a) == 'unanswerable':
        c['adapted_says_unanswerable'] += 1; c['vqa_from_unanswerable'] += s
    else:
        c['vqa_from_content'] += s
    fa = frozen_test_ans.get(q, '')
    c['frozen_vqa'] += ns['vqa_accuracy'](fa, g)
    c['frozen_says_unanswerable'] += int(norm(fa) == 'unanswerable')
for c in cat.values():
    for k in ('vqa_from_unanswerable', 'vqa_from_content', 'frozen_vqa'):
        c[k + '_mean'] = round(c.pop(k) / c['n'], 3)
save('P1_default', {
    'cell_seconds': timing, 'total_cell_seconds': round(sum(timing.values()), 1),
    'device': str(ns['pipe'].device), 'fetched': ns['fetched'],
    'raw_rows': ns['raw_rows'], 'splits': ns['disjoint'],
    'comparison': cmp, 'history': [{k: v for k, v in h.items()} for h in hist],
    'best_epoch': ns['adapt_result']['best_epoch'], 'n_trainable': ns['adapt_result']['n_trainable'],
    'reload_parity': ns['parity'], 'outputs': sorted(os.listdir('outputs')),
    'scene_frozen_vs_adapted': [(b['answer'], a['answer']) for b, a in zip(ns['results'], ns['adapted_results'])],
    'adapted_test_answer_analysis_by_category': dict(cat),
    'adapted_test_answers_found': len(first_test), 'frozen_test_answers_found': len(frozen_test_ans),
    'adapted_answer_counts': dict(__import__('collections').Counter(first_test.values()).most_common(12)),
})
results.pop('P1_progress', None)

# ---------------------------------------------------------------- P2 documented experiment rerun (cell 19 only)
p1_adapted_val = round(ns['adapted_val']['vqa_accuracy'], 3)
true_frozen_val = hist[0]['val']['vqa_accuracy']
captured = []
t = run(ns, 19, EPOCHS=1, TRAINABLE_DECODER_LAYERS=4)
h2 = ns['adapt_result']['history']
save('P2_rerun_section7', {
    'change': 'TRAINABLE_DECODER_LAYERS = 4 (documented optional experiment), EPOCHS = 1 (time cap); rerun of cell 19 only after the full default run',
    'seconds': t,
    'epoch0_note': h2[0].get('note'), 'epoch0_val_vqa_accuracy': h2[0]['val']['vqa_accuracy'],
    'true_frozen_val_vqa_accuracy_from_P1': true_frozen_val,
    'P1_adapted_val_vqa_accuracy': p1_adapted_val,
    'history': h2, 'best_epoch': ns['adapt_result']['best_epoch'],
    'n_trainable_reported': ns['adapt_result']['n_trainable'],
    'frozen_test_still_true_frozen': round(ns['frozen_test']['vqa_accuracy'], 3),
})
print('done')
